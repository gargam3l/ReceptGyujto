# ReceptGyujto

Szükséges előkövetelmények:
1. Oracle Database Express feltelpítése
2. Oracle database express homapage-en adminként a hr felhasználó unlock-olása, hr jelszó megadása, ill CREATE TABLE plusz jogosultság megadása
